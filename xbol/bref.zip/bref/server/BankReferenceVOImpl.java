package xxgam.oracle.apps.xbol.bref.server;

import oracle.apps.fnd.framework.server.OAViewObjectImpl;

public class BankReferenceVOImpl
  extends OAViewObjectImpl {
    /**This is the default constructor (do not remove)
     */
    public BankReferenceVOImpl() {
    }
}


/* Location:              C:\Users\GHCM-T430-06_2\Documents\Aeromexico\iExpenses\Fuentes\Link_referencia\bref_01_06_18.zip!\bref\server\BankReferenceVOImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */