package xxgam.oracle.apps.inv.moveorder.server;

import oracle.apps.fnd.framework.server.OAViewObjectImpl;

public class xXGamInvSoliRenderedVOImpl extends OAViewObjectImpl {

    /**This is the default constructor (do not remove)
     */
    public xXGamInvSoliRenderedVOImpl() {
    }
}
