package xxgam.oracle.apps.inv.moveorder.server;

import oracle.apps.fnd.framework.server.OAViewObjectImpl;

public class xXGamInvSoliDtlDisabledVOImpl extends OAViewObjectImpl {

}