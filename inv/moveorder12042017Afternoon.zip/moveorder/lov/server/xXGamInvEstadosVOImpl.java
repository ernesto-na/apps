package xxgam.oracle.apps.inv.moveorder.lov.server;

import oracle.apps.fnd.framework.server.OAViewObjectImpl;

public class xXGamInvEstadosVOImpl extends OAViewObjectImpl {

}