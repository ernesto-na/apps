package xxgam.oracle.apps.inv.moveorder.lov.server;

import oracle.apps.fnd.framework.server.OAViewObjectImpl;

public class xXGamInvTallaVOImpl extends OAViewObjectImpl
{

  /**This is the default constructor (do not remove)
   */
  public xXGamInvTallaVOImpl()
  {
  }
}
